# Vector Studio - VectorNiche Max

AI-Powered Vector Asset Generation platform.

## 🚀 GitHub Pages URL
```
https://<username>.github.io/Vector/
```

## 🛠️ Development

```bash
# Install dependencies
npm install

# Run dev server
npm run dev

# Build for production (outputs to docs/)
npm run build

# Preview production build
npm run preview
```

## 📦 Deployment (GitHub Pages)

### Auto Deploy (GitHub Actions)
Setiap push ke branch `main` akan otomatis build dan deploy.

### Manual Deploy
1. Jalankan `npm run build` → output ke folder `docs/`
2. Commit dan push folder `docs/`
3. Di GitHub: Settings → Pages → Source: `main` branch, folder `/docs`

## 📁 Struktur Proyek

```
Vector/
├── src/
│   ├── App.jsx              # Entry component
│   ├── Dashboard.jsx        # Dashboard utama
│   ├── VectorStudio.jsx     # Vector generator
│   ├── VectorNicheMaxLanding.jsx  # Landing page
│   ├── main.jsx
│   └── index.css
├── docs/                    # Build output untuk GitHub Pages
│   ├── index.html           # ← Entry point GitHub Pages
│   └── assets/              # CSS & JS compiled
├── .github/workflows/
│   └── deploy.yml           # Auto-deploy workflow
├── vite.config.js           # base: '/Vector/', outDir: 'docs'
└── package.json
```
